#include <stdio.h>
int obeb(int x,int y)
{
   if(y==0)
        return x;
   else
        return obeb(y,x%y);
}
int main()
{
  int sayi1,sayi2;
  printf("obebi bulunmak istenen iki sayiyi giriniz:");
  scanf("%d %d",&sayi1,&sayi2);
  printf(" %d , %d sayilarinin obeb'i %d 'dir",sayi1,sayi2,obeb(sayi1,sayi2));
  return 0;
}
