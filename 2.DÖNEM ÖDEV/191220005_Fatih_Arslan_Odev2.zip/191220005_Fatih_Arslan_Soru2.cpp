#include <stdio.h>
int toplam(int);
int main() {
    int sayi;
    printf("lutfen bir sayi giriniz:");
	scanf("%d" , &sayi);
    int sonuc = toplam(sayi);
    printf("sonuc = %d\n", sonuc);
    return 0;
}
 
int toplam(int x) {
    if (x == 1)
        return 1;
    return x + toplam(x - 1);
}
